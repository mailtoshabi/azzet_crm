<?php

namespace App\Models;

use App\Http\Utilities\Utility;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Shanmuga\LaravelEntrust\Models\EntrustRole;

class Role extends EntrustRole
{
    use HasFactory;
    protected $guarded=[];

    public function scopeOfType($query, $type)
    {
        return $query->where('user_type', $type)->where('id','!=',Utility::ROLE_ADMIN);
    }
}
